const menuToggle=document.querySelector('.menu-toggle');const navLinks=document.querySelector('.nav-links');
menuToggle?.addEventListener('click',()=>navLinks.classList.toggle('open'));
document.querySelectorAll('.nav-links a').forEach(a=>a.addEventListener('click',()=>navLinks.classList.remove('open')));

const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

const form=document.getElementById('leadForm'),status=document.getElementById('formStatus');
form.addEventListener('submit',e=>{
  e.preventDefault();
  const data=new FormData(form);
  if(!data.get('name')||!data.get('email')||!data.get('phone')){status.textContent='Будь ласка, заповніть ім’я, email і телефон.';return}
  status.textContent='Дякуємо! Заявку підготовлено. Для реального надсилання підключіть backend або CRM.';
  form.reset();
});

document.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener('click',e=>{
  const id=link.getAttribute('href');if(id==='#')return;
  const target=document.querySelector(id);if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'})}
}));

window.addEventListener('scroll',()=>{
  document.querySelector('.header').style.boxShadow=window.scrollY>20?'0 8px 30px rgba(0,0,0,.25)':'none';
});
